public class StationarySprite extends Sprite {
    public StationarySprite(double x, double y, int width, int height, String image) {
        super(x, y, width, height, image);
    }

    @Override
    public void step(World world) {}
}
