public class Runner 
{
	public static void main(String[] args)
	{
		SandLab lab = new SandLab(100, 60);
		lab.run();
	}
}
